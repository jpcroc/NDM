program constructionscript

	implicit none

	! ----------------
	real :: stressstep, currentstress
	integer :: nbsimu, i
	character(LEN=6) :: dirname
	! ----------------

	OPEN(unit=29, file='stress.input', status='old', action='read')
	Read(29, *) currentstress 
	Read(29, *) stressstep
	Read(29, *) nbsimu
	Close(29)

	OPEN(unit=30, file='scriptNDM', status='replace', action='write')
	OPEN(unit=31, file='stockstress.dat', status='replace', action='write')

	DO i=1,nbsimu
		dirname = 'step00'
		WRITE(dirname(5:6),'(i2.2)') i

		WRITE(30,*) 'ifort -c construiredin.F90'
		WRITE(30,*) 'ifort -O -o construiredin construiredin.o'
		WRITE(30,*) 'construiredin'
		WRITE(30,*) 'RUNDM'
		WRITE(30,*) 'rm babel.miniscript'
		WRITE(30,*) 'conversion'
		WRITE(30,*) 'chmod +x babel.miniscript'
		WRITE(30,*) 'babel.miniscript'
		WRITE(30,*) 'sauvercoller'
		WRITE(30,*) '~/Babel_V7.1/bin/babel input.babel.mol'
		WRITE(30,*) 'mv babel.miniscript repertoire_sauve' ! -----------------
		WRITE(30,*) 'rm fe.gin'
		WRITE(30,*) 'mv fe.next.gin fe.gin'		
		WRITE(30,*) 'grep deformation repertoire_sauve/xoxo.param.out.dat >> deformation.dat'
		WRITE(30,*) 'effacer'
		WRITE(30,'(a,a)') 'mv repertoire_sauve ', dirname

		Write(31,*)  currentstress+ (i-1) * stressstep
	END DO

	Write(30,*) 'paste deformation.dat stockstress.dat > hooklaw.dat'

	Close(30)
	Close(31)

end program constructionscript





