program conversion

	implicit none

	! ----------------------------------------------------
	
	integer :: derniereit, i, j, k, IM
	real :: a1, a2, a3, b1, b2, b3, c1, c2, c3
	character(LEN=16) :: molname

	OPEN(unit=216, file='xoxo.last_iteration.dat', status='old', action='read')
		READ(216,*) derniereit
		WRITE(6, '(a,i)') 'derniere iiiiiiiiiiiiiiiiiit : ', derniereit
	CLOSE(unit=216)

	OPEN(unit=236, file='fe.gin', status='old',action='read')
		READ(236, '(i,i,i)') i, j, k
		READ(236,'(3(g24.16,1x))') a1, a2, a3
		READ(236,'(3(g24.16,1x))') b1, b2, b3
		READ(236,'(3(g24.16,1x))') c1, c2, c3
		READ(236, *) IM
	CLOSE (236)

	molname ='fe.000000000.mol'
	WRITE(molname(4:12), '(i9.9)') derniereit
	WRITE(*,*) molname

	OPEN(unit=226, file=molname, status='old', action='write', position='append')
		WRITE(226,*) ' '
		WRITE(226, '(f,f,f)') a1, a2, a3
		WRITE(226, '(f,f,f)') b1, b2, b3
		WRITE(226, '(f,f,f)') c1, c2, c3
		WRITE(226,*) ' ' 
		WRITE(226,*) 1.
	CLOSE (226)

	OPEN(unit=661, file='babel.miniscript', status='replace', action='write')
	  WRITE(661, '(a,a,a)') 'mv ',molname, ' fe_new.xyz'
	CLOSE(661)

end program conversion



