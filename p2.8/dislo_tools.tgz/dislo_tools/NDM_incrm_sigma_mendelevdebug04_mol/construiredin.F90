program construiredin

	implicit none

! ---------------------------------------------
	integer :: nbsimu
	real :: currentstress, stressstep
! ---------------------------------------------

	Open(unit=20, file='stress.input', status='old', action='read')
	Read(20,'(f)') currentstress
	Read(20,'(f)') stressstep
	Read(20,'(i)') nbsimu
	Close(20)

	Open(unit=21, file='fe.din', status='replace', action='write')

		Write(21, *) '&input'
		Write(21, *) '        ipotentiel=10  ! potentiel lu dans eamtab.potin'
	 	Write(21, *) '        dmtype=2   ! (1: DM Verlet position, etc.)'
		Write(21, *) '        igen=0	! structure generee a partir de fichier .gin (0)'
	  	Write(21, *) '        fpstop = 0.0001 '
	  	Write(21, *) '        fsumstop = -1.0'
	   	Write(21, *) '        dfpred=0.1 ! ! eguess for GC calculations and quenching'
	   	Write(21, *) '        lcontr=.false.'
	    	Write(21, *) '        lginread=.true.'
	     	Write(21, *) '        lsigat=.false.  ! contrainte par atome'
	     	Write(21, *) '        lperiod=.false.'
	     	Write(21, *) '        ngrid=180000'
	     	Write(21, *) '        lpr=.false.'
	     	Write(21, *) '        lprteat=.true.'
	   	Write(21, *) '        ltabvois=.true. ! table des voisins'
	   	Write(21, *) '        lconstrtot=.false. !construction de la table des voisins '
	   	Write(21, *) '        rvois=6.0       ! rayon de la table des voisins'
	   	Write(21, *) '        itetabvois=4	! periode de calcul de la table des  voisins'
   	   	Write(21, *) '        itetemp=1	! affichage de la temperature tout les itetemp'
          	Write(21, *) '        itesigma=1	! idem contrainte contrainte'
          	Write(21, *) '        itedepla=-1	! idem - deplacements des atomes'
          	Write(21, *) '        itecoordo=-1	! idem - coordination'
          	Write(21, *) '        itesauv=100000	! sauvegarde complete tous les ..'
           	Write(21, *) '        lEeV=.true.	! energies en eV'
          	Write(21, *) '        lPkbar=.true.   ! pression en Kbar'
          	Write(21, *) '        imm=  12600'
           	Write(21, *) '        itmax=10000'
          	Write(21, *) '        tstep= 2.0000000'
          	Write(21, *) '        tinit= 0.0'
           	Write(21, *) '        iterasmol= 100'
         	Write(21, *) '        ibound = 2'
         	Write(21, '(a,f)') '        user_stress_xy =', currentstress
	   	Write(21, *) '        itespebcout = 50'
	  ! 	Write(21, *) '        ldecal_bc=.true.'
	 !  	Write(21, *) '        decal_bc = 0.0500'
	!   	Write(21, *) '        lperiod=.true.'
	   	Write(21, *) '&end'

	Close(21)

	Open(unit=22, file='stress.input', status='replace', action='write')
	WRITE(22,'(f)') currentstress + stressstep
	WRITE(22,'(f)') stressstep
	WRITE(22,'(i)') nbsimu
	Close(22)

end program construiredin





