	implicit none
	double precision x(100000),y(100000),z(100000)
	double precision x0(100000),y0(100000),z0(100000),burg, dist
	double precision rcut,xij,yij,zij,xm,ym,xi,yi,xf,yf,l,rrr
	double precision dunit,xbi,xbf,ybi,ybf,xbi2,ybi2,xbf2,ybf2
        integer nat,i,j,kounter
	kounter=0
        burg=dsqrt(3.d0)/2.d0
        open (unit=10,file='pos.dat',status='unknown')
        print *,"set size square"
        print *,"set pointsize 1"
        print *,"set border 0"
        print *,"unset ytics"
        print *,"unset xtics"
        print *,"set yrange[5.0:20.0]"
        print *,"set xrange [10.0:25.0]"
        print *,"set size square"
        print *,"plot 'pos1215.dat' w points "
        print *,"replot 'pos1215_core.dat' w points "
        print *,"unset key"
        rcut=1.3
	read(5,*) nat, dunit
	do i=1,nat
	read(5,*) x(i),y(i),z(i)
	x(i)=x(i)/dunit
        y(i)=y(i)/dunit
        z(i)=z(i)/dunit
        enddo
	do i=1,nat
	read(5,*) x0(i),y0(i),z0(i)
        write(10,'(2f12.6)') x0(i),y0(i)
	enddo
	do i=1,nat-1
	do j=i+1,nat
        xij=x(j)-x(i)
	yij=y(j)-y(i)
        zij=z(j)-z(i)-(z0(j)-z0(i))
        zij=zij-burg*nint(zij/burg)
	rrr=dsqrt(xij*xij+yij*yij)
	if(rrr.le.rcut.and.rrr.gt.1.d-6) then
          xm=(x(i)+x(j))/2.d0
	  ym=(y(i)+y(j))/2.d0
	  l=zij*rrr*3/burg
	  xi=xm-xij/rrr*l/2.d0
	  yi=ym-yij/rrr*l/2.d0
	  xf=xm+xij/rrr*l/2.d0
	  yf=ym+yij/rrr*l/2.d0
          kounter=kounter+1
          write(6,'("set arrow   ",i12," from",f12.6,",",f12.6
     #               ," to ",f12.6,",",f12.6)') 
     #    kounter,xi,yi,xf,yf
         endif
        enddo
	enddo
        print *,"replot"
        print *,"set term postscript enhanced color"
        print *,"set out 'vitek.ps'"
	print *,"replot"
	end
