c       transform cartesian in scaled cartesian
c       keep only one plane
        implicit none
        double precision x(3,100000),dunit,bin
        integer index(100000),nat,k,irepz,nrepz,idum,i,j
        character*2 label

        read (5,*) nat
        nrepz=10
c        dunit=2.8553
	dunit=2.8148
        read(5,*) bin 
        do i=1,nat
          read (5,*) label,x(1,i),x(2,i),x(3,i)
        enddo
        write(6,'(i6,f12.7)') nat/nrepz, dunit/dunit
        do k=1,nat/nrepz
        write(6,'(3f16.8)') x(1,k)/dunit,
     #                      x(2,k)/dunit,
     #                      x(3,k)/dunit
        enddo
        end

