

program gen_boite
	! -----------------------------------------------
	implicit none
	! -----------------------------------------------
	integer :: nx, ny, nattot, i, j, i1, i2, i3
	integer :: i_x_sup, i_x_inf, i_y_sup, i_y_inf
	real :: a, b, c, paramaille
	real, dimension(3) :: at1, at2, at3
	real, allocatable, dimension(:,:) :: positions
	logical :: ldislo
	real :: xmax, xmin, ymax, ymin, y_midd, x_midd, dist
	! -----------------------------------------------
	real, dimension(2,2) :: matROT
	real :: MAX_COOR1, MAX_COOR2, pos1, pos2, ANGLE, ANGLE_DEG,DISLO_save1,DISLO_save2, a_1, a_2
	logical :: lrotate
	integer :: compteur
	real, allocatable, dimension(:,:) :: posit_bis, posit_grand, positions2
	real :: Centre1, Centre2, POS1D, POS2D, DIUST, POS1Dtemp, POS2Dtemp, dY_compar
	integer :: icentrer
	real :: margeXY, centrerY, centrerX, margeY, margeX

	! -----------------------------------------------

	! ----------------------------------------------------------------------
	! ----------------------------------------------------------------------
        ! ---------- ce programme sert à générer un fichier .xyz ou .gin pour NDM

	! ----------------------------------------------------------------------	
	! ----------------------------------------------------------------------
	! ------- PARAMETRES D'ENTREE ------------------------------------------
	! ----------------------------------------------------------------------

! Rq : nécessite d'avoir BABEL installé

! POUR IMPOSER LES DIMENSION DE LA BOITE

	! attention : nx doit etre un multiple de 3
	!	      ny doit etre un multiple de 2 si on veut utiliser lrotate=.true.
	nx = 45
	ny = 28
       !nz = 10, ici

	paramaille = 2.8148	! parametre de maille

 ! SI ON VEUT UNE MARGE

	margeXY=6. ! marge identique selon X et selon Y

 ! POUR CENTRER OU NON LA BOITE

	icentrer = 2 	  ! icentrer=0 => ne pas centrer
			  ! icentrer=1 => centrer selon Y, periodique selon X
			  ! icentrer=2 => surface selon Y et X, centrer selon les deux

 ! POUR GERER LA ROTATION DES POSITIONS AUTOUR DE L'AXE (Oz)

	lrotate = .true.
	ANGLE_DEG = 15.
	ANGLE = ANGLE_DEG * 3.141592 / 180.
	! si lrotate=.true. on génère un .gin directemetn
	! sinon, on génère un .xyz ----> il faut utiliser babel ensuite

! POUR INTRODUIRE UNE DISLOCATON

	ldislo = .true.







	! -----------------------------------------------

	nattot = nx*ny
	IF(icentrer==0) THEN
		centrerX= 0.
		centrerY= 0.
		margeX  = 0.
		margeY  = 0.
	ELSE IF (icentrer==1) THEN
		centrerX= 0.
		margeX  = 0.
		centrerY= margeXY/2.
		margeY  = margeXY
	ELSE IF (icentrer==2) THEN
		centrerX= margeXY/2.
		margeX  = margeXY
		centrerY= margeXY/2.
		margeY  = margeXY
	END IF

	allocate (positions(nattot,3))

	at1(1) = 0.0000000
	at1(2) = 0.0000000
	at1(3) = 0.0000000

	at2(1) = 0.8164970
	at2(2) = 0.0000000
	at2(3) = 0.5773500

	at3(1) = 1.6329930
	at3(2) = 0.0000000
	at3(3) = 0.2886750

	positions(1,1) = 0.0000000
	positions(1,2) = 0.0000000
	positions(1,3) = 0.0000000

	positions(2,1) = 0.8164970
	positions(2,2) = 0.0000000
	positions(2,3) = 0.5773500

	positions(3,1) = 1.6329930
	positions(3,2) = 0.0000000
	positions(3,3) = 0.2886750

	do i=4,nx
		positions(i,1) = positions(i-3,1) + 2.4494900
		positions(i,2) = 0.0000000
		positions(i,3) = positions(i-3,3)
	end do

	at1(1) = 0.4082480
	at1(2) = 0.7071070
	at1(3) = 0.2886750

	at2(1) = 1.2247450
	at2(2) = 0.7071070
	at2(3) = 0.0000000

	at3(1) = 2.0412410
	at3(2) = 0.7071070
	at3(3) = 0.5773500

	positions(nx+1,1) = 0.4082480
	positions(nx+1,2) = 0.7071070
	positions(nx+1,3) = 0.2886750

	positions(nx+2,1) = 1.2247450
	positions(nx+2,2) = 0.7071070
	positions(nx+2,3) = 0.0000000

	positions(nx+3,1) = 2.0412410
	positions(nx+3,2) = 0.7071070
	positions(nx+3,3) = 0.5773500

	do i=nx+4,2*nx
		positions(i,1) = positions(i-3,1) + 2.4494900
		positions(i,2) = 0.7071070
		positions(i,3) = positions(i-3,3)
	end do

	do j=3,ny
	    do i=1,nx 
		positions(2*nx+i+(j-3)*nx,1)=positions(i+(j-3)*nx,1)
		positions(2*nx+i+(j-3)*nx,2)=positions(i+(j-3)*nx,2) + 1.4142140
		positions(2*nx+i+(j-3)*nx,3)=positions(i+(j-3)*nx,3)
	    end do
	end do

	IF (lrotate==.false.) THEN
		Open ( unit=31, file='fe_new.xyz', status='unknown', action='write' )
	ELSE IF (lrotate==.true.) THEN
		Open ( unit=31, file='fe_new_pasROT.xyz', status='unknown', action='write' )
	END IF

	Write(31,'(i7)') nattot
	Write(31,*) ' '
	a=0.
	b=0.
	c=0.
	Do i=1,nattot
	   a = positions(i,1)+centrerX
	   b = positions(i,2)+centrerY
	   c = positions(i,3)
	   Write(31,'(a2,4x,f10.7,4x,f10.7,4x,f10.7)') 'Fe', a, b, c
	End do

	Write(31,*) ' '
	Write(31,'(f10.7,4x,f10.7,4x,f10.7)') positions(nx,1)+0.8164970+margeX, 0., 0.
	Write(31,'(f10.7,4x,f10.7,4x,f10.7)') 0., positions(nattot,2)+0.7071070+margeY, 0.
	Write(31,'(f10.7,4x,f10.7,4x,f10.7)') 0., 0., positions(2,3)+0.2886750
	Write(31,*) ' '
	Write(31,*) paramaille

	Close(31)

	! -----------------------------------------------

     if (ldislo==.true.) then

	xmax = positions(1,1)
	xmin = positions(1,1)
	ymax = positions(1,2)
	ymin = positions(1,2)
	do i=2,nattot
	  if (i<=nx) then
	    if(positions(i,1) > xmax) xmax = positions(i,1)
	    if(positions(i,1) < xmin) xmin = positions(i,1)
	  end if
	    if(positions(i,2) > ymax) ymax = positions(i,2)
	    if(positions(i,2) < ymin) ymin = positions(i,2)
	end do
	x_midd = (xmax + xmin)/2
	y_midd = (ymax + ymin)/2

	dist = 666666.
	i1 = 666
	i2 = 666
	i3 = 666
	do i=1,nattot
	   if ((positions(i,1)-x_midd)*(positions(i,1)-x_midd)+(positions(i,2)-y_midd)*(positions(i,2)-y_midd) < dist ) then
		dist = (positions(i,1)-x_midd)*(positions(i,1)-x_midd)+(positions(i,2)-y_midd)*(positions(i,2)-y_midd)
		i1 = i
	   end if
	end do
	do i=1,nattot
	   if (ABS(positions(i,2)-positions(i1,2)) < 0.05 .AND. ABS(positions(i,1)-(positions(i1,1)+0.8164970)) < 0.05) i3 = i
	   if (ABS(positions(i,2)-(positions(i1,2)+0.7071070)) < 0.05 .AND. ABS(positions(i,1)-(positions(i1,1)+0.8164970/2.)) < 0.05) i2 = i
	end do

	IF (lrotate==.false.) Open(unit=55, file='pos_core.dat', status='unknown', action='write')
	IF (lrotate==.true.)  Open(unit=55, file='pos_core_PASrot.dat', status='unknown', action='write')
	   a = positions(i2,1)
	   b = (positions(i2,2)+positions(i1,2))/2.
	 	DISLO_save1 = a
		DISLO_save2 = b
	   Write(55, '(f10.7,4x,f10.7,4x,f10.7,4x)') a+centrerX, b+centrerY, 0.
	   Write(55, '(f10.7,4x,f10.7,4x,f10.7,4x,i7)') positions(i1,1)+centrerX, positions(i1,2)+centrerY, positions(i1,3) , i1
	   Write(55, '(f10.7,4x,f10.7,4x,f10.7,4x,i7)') positions(i2,1)+centrerX, positions(i2,2)+centrerY, positions(i2,3) , i2
	   Write(55, '(f10.7,4x,f10.7,4x,f10.7,4x,i7)') positions(i3,1)+centrerX, positions(i3,2)+centrerY, positions(i3,3) , i3
	   Close(55)

	xmax = positions(1,1)
	xmin = positions(1,1)
	ymax = positions(1,2)
	ymin = positions(1,2)
	do i=2,nattot
	  if (i<=nx) then
	    if(positions(i,1) > xmax) xmax = positions(i,1)
	    if(positions(i,1) < xmin) xmin = positions(i,1)
	  end if
	    if(positions(i,2) > ymax) ymax = positions(i,2)
	    if(positions(i,2) < ymin) ymin = positions(i,2)
	end do

	Write (*,*) ' '
	Write (*,*) 'Lx (nm) : '
	Write (*,*) (xmax-xmin)*paramaille/10
	Write (*,*) ' '
	Write (*,*) 'Ly (nm) : '
	Write (*,*) (ymax-ymin)*paramaille/10

        end if

	! -----------------------------------------------   
	IF (lrotate==.false.) THEN
		Deallocate (positions)
	ELSE IF (lrotate==.true.) THEN


	! ------------------------ ON EFFECTUE LA ROTATION --------------------------
	! ---------------------------------------------------------------------------
	
	! matrice de rotation: 

	matROT(1,1) =  COS(ANGLE)
	matROT(1,2) = -SIN(ANGLE)
	matROT(2,2) =  COS(ANGLE)
	matROT(2,1) = +SIN(ANGLE)

	!Coins:
	MAX_COOR1 = positions(nx,1)    + 0.8164970
	MAX_COOR2 = positions(nattot,2)+ 0.7071070

	Allocate (posit_grand(9*nattot,3))
	posit_grand(:,:) = -222.

	Do i=1,nattot
		posit_grand(i,1) = positions(i,1)           !1
		posit_grand(i,2) = positions(i,2)
		posit_grand(i,3) = positions(i,3)
 		
		posit_grand(i+nattot,1) = positions(i,1)-MAX_COOR1 !2
		posit_grand(i+nattot,2) = positions(i,2)
		posit_grand(i+nattot,3) = positions(i,3)

 		posit_grand(i+2*nattot,1) = positions(i,1)-MAX_COOR1 !3
		posit_grand(i+2*nattot,2) = positions(i,2)-MAX_COOR2
		posit_grand(i+2*nattot,3) = positions(i,3)
 		
		posit_grand(i+3*nattot,1) = positions(i,1)           !4
		posit_grand(i+3*nattot,2) = positions(i,2)-MAX_COOR2
		posit_grand(i+3*nattot,3) = positions(i,3)

 		posit_grand(i+4*nattot,1) = positions(i,1)+MAX_COOR1 !5
		posit_grand(i+4*nattot,2) = positions(i,2)-MAX_COOR2
		posit_grand(i+4*nattot,3) = positions(i,3)
 
		posit_grand(i+5*nattot,1) = positions(i,1)+MAX_COOR1 !6
		posit_grand(i+5*nattot,2) = positions(i,2)
		posit_grand(i+5*nattot,3) = positions(i,3)
 
		posit_grand(i+6*nattot,1) = positions(i,1)+MAX_COOR1 !7
		posit_grand(i+6*nattot,2) = positions(i,2)+MAX_COOR2
		posit_grand(i+6*nattot,3) = positions(i,3)

		posit_grand(i+7*nattot,1) = positions(i,1)           !8
		posit_grand(i+7*nattot,2) = positions(i,2)+MAX_COOR2
		posit_grand(i+7*nattot,3) = positions(i,3)

		posit_grand(i+8*nattot,1) = positions(i,1)-MAX_COOR1 !9
		posit_grand(i+8*nattot,2) = positions(i,2)+MAX_COOR2
		posit_grand(i+8*nattot,3) = positions(i,3)
	End do

	!Centre1 = MAX_COOR1/2.
	!Centre2 = MAX_COOR2/2.

	Allocate(posit_bis(9*nattot,3)) !INT(1.1*REAL(nattot))))
	posit_bis(:,:) = -11.
	compteur = 0
   
	!rotation des positions et selection des positions
	DO i=1,9*nattot
		!pos1 = (posit_grand(i,1)-Centre1)*matROT(1,1)+(posit_grand(i,2)-Centre2)*matROT(1,2)
		!pos2 = (posit_grand(i,1)-Centre1)*matROT(2,1)+(posit_grand(i,2)-Centre2)*matROT(2,2)
		!pos1 = pos1 + Centre1
		!pos2 = pos2 + Centre2
		pos1 = posit_grand(i,1)*matROT(1,1)+posit_grand(i,2)*matROT(1,2)
		pos2 = posit_grand(i,1)*matROT(2,1)+posit_grand(i,2)*matROT(2,2)
		posit_grand(i,1)=pos1
		posit_grand(i,2)=pos2

		IF(posit_grand(i,1)>=0. .AND. posit_grand(i,1)<MAX_COOR1) THEN
		IF(posit_grand(i,2)>=0. .AND. posit_grand(i,2)<MAX_COOR2) THEN	
		 compteur = compteur + 1
		 posit_bis(compteur,:)=posit_grand(i,:)
		END IF
		END IF		
	END DO

	write(*,*) compteur

	Allocate(positions2(compteur,3))

	DO i=1,compteur
		positions2(i,:) = posit_bis(i,:)
	END DO

        ! ecriture du fichier de sortie
	Open ( unit=318, file='fe_new.xyz', status='unknown', action='write' )
	
	Write(318,'(i7)') compteur
	Write(318,*) ' '
	a=0.
	b=0.
	c=0.
	Do i=1,compteur
	   a = positions2(i,1)+centrerX
	   b = positions2(i,2)+centrerY
	   c = positions2(i,3)
	   Write(318,'(a2,4x,f10.7,4x,f10.7,4x,f10.7)') 'Fe', a, b, c
	End do

	Write(318,*) ' '
	Write(318,'(f10.7,4x,f10.7,4x,f10.7)') MAX_COOR1 + margeX, 0., 0.
	Write(318,'(f10.7,4x,f10.7,4x,f10.7)') 0., MAX_COOR2 + margeY, 0.
	Write(318,'(f10.7,4x,f10.7,4x,f10.7)') 0., 0., positions(2,3)+0.2886750
	Write(318,*) ' '
	Write(318,*) paramaille

	Close(318)

!	a_1 = DISLO_save1*matROT(1,1)+DISLO_save2*matROT(1,2)
!	a_2 = DISLO_save1*matROT(2,1)+DISLO_save2*matROT(2,2)

!	a_1 = (DISLO_save1-Centre1)*matROT(1,1)+(DISLO_save2-Centre2)*matROT(1,2)
!	a_2 = (DISLO_save1-Centre1)*matROT(2,1)+(DISLO_save2-Centre2)*matROT(2,2)
!	a_1 = a_1 + Centre1
!	a_2 = a_2 + Centre2

	a_1 = DISLO_save1*matROT(1,1)+DISLO_save2*matROT(1,2)
	a_2 = DISLO_save1*matROT(2,1)+DISLO_save2*matROT(2,2)

!	if (pos1 >= MAX_COOR1) a_1 = a_1 - MAX_COOR1
!	if (pos1 < 0.)         a_1 = a_1 + MAX_COOR1
!	if (pos2 >= MAX_COOR2) a_2 = a_2 - MAX_COOR2
!	if (pos2 < 0.)         a_2 = a_2 + MAX_COOR2

!	Open ( unit=478, file='pos_core.dat', status='unknown', action='write' )
!	Write(478, '(f10.7,4x,f10.7,4x,f10.7,4x)') a_1, a_2, 0.
!	Close(478)

     ! RECENTRONS LA DISLO DANS LA BOITE
	POS1D = a_1
	POS2D = a_2
	dY_compar = ABS(POS2D-MAX_COOR2/2.)
	DIUST = SQRT(0.4082480*0.4082480+0.7071070*0.7071070)

	IF (ANGLE >= 0.) THEN
		DO i=1,INT(REAL(ny)/2.)
		   POS1Dtemp = POS1D + SIN(30.*3.141592/180.+ANGLE)*DIUST
		   POS2Dtemp = POS2D - COS(30.*3.141592/180.+ANGLE)*DIUST
		   IF ( ABS(POS2Dtemp-MAX_COOR2/2.) < dY_compar)THEN
			POS1D = POS1Dtemp
			POS2D = POS2Dtemp
			dY_compar = ABS(POS2Dtemp-MAX_COOR2/2.)
		   END IF
		END DO
	ELSE IF (ANGLE < 0.) THEN
		DO i=1,INT(REAL(ny)/2.)
	 	   POS1Dtemp = POS1D - SIN(30.*3.141592/180.+ANGLE)*DIUST
		   POS2Dtemp = POS2D + COS(30.*3.141592/180.+ANGLE)*DIUST
		   IF ( ABS(POS2Dtemp-MAX_COOR2/2.) < dY_compar)THEN
			POS1D = POS1Dtemp
			POS2D = POS2Dtemp
			dY_compar = ABS(POS2Dtemp-MAX_COOR2/2.)
		   END IF
		END DO
	END IF


	Open ( unit=478, file='pos_core.dat', status='unknown', action='write' )
	Write(478, '(f10.7,4x,f10.7,4x,f10.7,4x)') POS1D+centrerX , POS2D+centrerY, 0.
	Close(478)

	CALL generer_inputbabel(compteur, POS1D+centrerX, POS2D+centrerY)

	Deallocate (positions)
	Deallocate (positions2)
	Deallocate (posit_bis)

	END IF ! lrotate = .true.

end program






subroutine generer_inputbabel(imm,POS1D,POS2D)

	implicit none

	! -------------------------------
	real :: alat, POS1D, POS2D
	integer :: burg, imm
	! -------------------------------
	burg = -1
	alat = 2.8148

	Open(unit=777, file='input.babel1215mou', status='replace', action='write')

	Write(777,*) '&input'
	Write(777,*) ' '
	Write(777,'(a,i)') '  imm=', imm*10
	Write(777,*) ' '
	Write(777,*) '  duplicate=.true.'
	Write(777,*) '  lat(3)=10'
	Write(777,*) ' '
	Write(777,*) '  anisotropic_elasticity=.true.'
	Write(777,*) '  CVoigt(1,1)=310.20'
	Write(777,*) '  CVoigt(1,2)=122.73'
	Write(777,*) '  CVoigt(1,3)=100.47'
	Write(777,*) '  CVoigt(1,5)=-31.490'
	Write(777,*) '  CVoigt(2,1)=122.73'
	Write(777,*) '  CVoigt(2,2)=310.20'
	Write(777,*) '  CVoigt(2,3)=100.47'
	Write(777,*) '  CVoigt(2,5)=31.490'
	Write(777,*) '  CVoigt(3,1)=100.47'
	Write(777,*) '  CVoigt(3,2)=100.47'
	Write(777,*) '  CVoigt(3,3)=332.47'
	Write(777,*) '  CVoigt(4,4)=71.467'
	Write(777,*) '  CVoigt(4,6)=31.490'
	Write(777,*) '  CVoigt(5,1)=-31.490'
	Write(777,*) '  CVoigt(5,2)=31.490'
	Write(777,*) '  CVoigt(5,5)=71.467'
	Write(777,*) '  CVoigt(6,4)=31.490'
	Write(777,*) '  CVoigt(6,6)=93.733'
	Write(777,*) ' '
	Write(777,*) '  dislo=.true.'
	Write(777,'(a,f)') '  alat=', alat
	Write(777,*) '  rc=1.0'
	Write(777,*) '  nd=1'
	Write(777,*) ' '
	Write(777,*) '  lDislo(1,1)=0.'
	Write(777,*) '  lDislo(2,1)=0.'
	Write(777,*) '  lDislo(3,1)=1.'
	Write(777,*) '  bDislo(1,1)=0.'
	Write(777,*) '  bDislo(2,1)=0.'
       IF (burg==-1) Write(777,*) '  bDislo(3,1)=-0.8660254037844386468'
       IF (burg== 1) Write(777,*) '  bDislo(3,1)=+0.8660254037844386468'
	Write(777,*) '  cDislo(1,1)=',POS1D
	Write(777,*) '  cDislo(2,1)=',POS2D
	Write(777,*) '  cDislo(3,1)=0.'
	Write(777,*) '  cutDislo(1,1)=1.'
	Write(777,*) '  cutDislo(2,1)=0.'
	Write(777,*) '  cutDislo(3,1)=0.'
!	Write(777,*) ' '
!  	Write(777,*) '  xImages=.TRUE.'
!  	Write(777,*) '  nxImages=40'
	Write(777,*) ' '
	Write(777,*) '  inpXyz=.true.'
	Write(777,*) "  inpFile='fe_new.xyz'" 
	Write(777,*) '  outGin=.true.'
	Write(777,*) "  outFile='fe.1.gin' "
	Write(777,*) ' '
	Write(777,*) '  fixGravity=.true.'
	Write(777,*) '&end'

	Close(777)

end subroutine generer_inputbabel

